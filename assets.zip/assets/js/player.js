import { getPlayers } from "./store.js";
import { renderEloGraph } from "./utils.js";

const id = new URLSearchParams(location.search).get("id");
const p = getPlayers().find(x => x.id === id);
const el = document.getElementById("profile");

if (!p) {
  el.innerHTML = "<p>Player not found.</p>";
} else {
  const season = Object.keys(p.seasons).slice(-1)[0];

  el.innerHTML = `
    <h1>${p.name}</h1>

    ${p.avatar
      ? `<img src="${p.avatar}">`
      : `<div class="avatar-fallback">${p.name[0]}</div>`}

    <div class="archetype ${p.archetype.toLowerCase()}">
      ${p.archetype}
    </div>

    <p><b>${season}</b></p>
    <p>Elo: ${p.seasons[season].elo}</p>

    ${renderEloGraph(p.seasons[season].history)}

    <h3>Tags</h3>
    ${p.tags.map(t => `<span class="role" data-tip="${t}">${t}</span>`).join("")}
  `;
}
