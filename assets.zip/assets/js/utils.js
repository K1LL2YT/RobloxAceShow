export function renderEloGraph(history = []) {
  if (history.length < 2) return "";

  const max = Math.max(...history);
  const min = Math.min(...history);

  const points = history.map((v, i) => {
    const x = (i / (history.length - 1)) * 140;
    const y = 44 - ((v - min) / (max - min || 1)) * 38;
    return `${x},${y}`;
  }).join(" ");

  const lastY = points.split(" ").pop().split(",")[1];

  return `
    <svg class="elo-graph" viewBox="0 0 140 44">
      <polyline points="${points}" />
      <circle cx="140" cy="${lastY}" r="3" />
    </svg>
  `;
}
