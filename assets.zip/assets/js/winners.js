import { getPlayers } from "./store.js";
import { getSeasons } from "./seasons.js";

const podium = document.getElementById("podium");
const season = getSeasons().slice(-1)[0];

const top = getPlayers()
  .filter(p => p.seasons?.[season]?.participated)
  .sort((a,b)=>b.seasons[season].elo - a.seasons[season].elo)
  .slice(0,3);

top.forEach((p,i)=>{
  podium.innerHTML += `
    <div class="podium-slot place-${i+1}"
         onclick="location.href='player.html?id=${p.id}'">
      ${p.avatar
        ? `<img class="podium-avatar" src="${p.avatar}">`
        : `<div class="avatar-fallback">${p.name[0]}</div>`}
      <h3>${["🥇","🥈","🥉"][i]} ${p.name}</h3>
      <p>Elo: ${p.seasons[season].elo}</p>
    </div>
  `;
});
