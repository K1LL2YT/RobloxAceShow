const games = {
  Easy: ["Speed Run", "Puzzle Dash"],
  Medium: ["Arena Clash", "Tower Defense"],
  Hard: ["Hardcore PvP", "Endurance Trials"]
};

const root = document.getElementById("games");

Object.entries(games).forEach(([lvl, list]) => {
  root.innerHTML += `<h2>${lvl}</h2><ul>${
    list.map(g=>`<li>${g}</li>`).join("")
  }</ul>`;
});
