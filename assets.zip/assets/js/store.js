const PLAYER_KEY = "TRAS_PLAYERS";

function migratePlayer(p) {
  // Already new schema
  if (p.seasons) return p;

  const seasons = {};

  // Old eloBySeason format
  if (p.eloBySeason) {
    for (const season in p.eloBySeason) {
      const s = p.eloBySeason[season];
      seasons[season] = {
        elo: s.current ?? 1000,
        history: s.history ?? [s.current ?? 1000],
        participated: true
      };
    }
  }

  // Old single season format
  if (p.season && typeof p.elo === "number") {
    seasons[p.season] = {
      elo: p.elo,
      history: [p.elo],
      participated: true
    };
  }

  return {
    id: p.id,
    name: p.name,
    avatar: p.avatar || "",
    archetype: p.archetype || "Strategist",
    tags: p.tags || [],
    seasons
  };
}

export function getPlayers() {
  const raw = JSON.parse(localStorage.getItem(PLAYER_KEY)) || [];
  const migrated = raw.map(migratePlayer);
  localStorage.setItem(PLAYER_KEY, JSON.stringify(migrated));
  return migrated;
}

export function savePlayers(players) {
  localStorage.setItem(PLAYER_KEY, JSON.stringify(players));
}

export function addPlayer(player) {
  const players = getPlayers();
  players.push(player);
  savePlayers(players);
}

export function updatePlayer(id, data) {
  const players = getPlayers();
  const i = players.findIndex(p => p.id === id);
  if (i !== -1) {
    players[i] = { ...players[i], ...data };
    savePlayers(players);
  }
}
