const merch = [
  { name: "Aced Crown", img: "https://via.placeholder.com/150", link: "#" },
  { name: "Neon Aura", img: "https://via.placeholder.com/150", link: "#" }
];

const root = document.getElementById("merch");

merch.forEach(m => {
  root.innerHTML += `
    <div class="player-card">
      <img src="${m.img}">
      <h3>${m.name}</h3>
      <a href="${m.link}">View</a>
    </div>
  `;
});
