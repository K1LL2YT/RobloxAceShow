import { getPlayers, addPlayer, updatePlayer } from "./store.js";
import { getSeasons, addSeason } from "./seasons.js";

const admin = document.getElementById("admin");
const nameInput = document.getElementById("new-name");
const seasonSelect = document.getElementById("new-season");

const BASE_ELO = 1000;

// Populate seasons
function refreshSeasons() {
  seasonSelect.innerHTML = "";
  getSeasons().forEach(s => {
    const o = document.createElement("option");
    o.value = s;
    o.textContent = s;
    seasonSelect.appendChild(o);
  });
}
refreshSeasons();

document.getElementById("add-season").onclick = () => {
  const v = document.getElementById("new-season-name").value.trim();
  if (!v) return;
  addSeason(v);
  refreshSeasons();
};

document.getElementById("add-player").onclick = () => {
  if (!nameInput.value.trim()) return;

  const season = seasonSelect.value;

  addPlayer({
    id: crypto.randomUUID(),
    name: nameInput.value.trim(),
    avatar: "",
    archetype: "Strategist",
    tags: [],
    seasons: {
      [season]: {
        elo: BASE_ELO,
        history: [BASE_ELO],
        participated: true
      }
    }
  });

  nameInput.value = "";
  render();
};

function render() {
  admin.innerHTML = "";

  getPlayers().forEach(p => {
    admin.innerHTML += `
      <details class="player-card">
        <summary>${p.name}</summary>

        <label>Season</label>
        <select onchange="window.selectSeason('${p.id}', this.value)">
          ${getSeasons().map(s => `
            <option value="${s}">${s}</option>
          `).join("")}
        </select>

        <label>Elo</label>
        <input type="number"
          value="${Object.values(p.seasons)[0].elo}"
          onchange="window.setElo('${p.id}', this.value)">

        <label>Tags</label>
        <input value="${p.tags.join(", ")}"
          onchange="window.setTags('${p.id}', this.value)">

        <button onclick="location.href='player.html?id=${p.id}'">
          Open Profile
        </button>
      </details>
    `;
  });
}

window.selectSeason = (id, season) => {
  const players = getPlayers();
  const p = players.find(x => x.id === id);

  if (!p.seasons[season]) {
    p.seasons[season] = {
      elo: BASE_ELO,
      history: [BASE_ELO],
      participated: true
    };
  }

  updatePlayer(id, p);
  render();
};

window.setElo = (id, val) => {
  const players = getPlayers();
  const p = players.find(x => x.id === id);
  const season = Object.keys(p.seasons).slice(-1)[0];

  p.seasons[season].elo = Number(val);
  p.seasons[season].history.push(Number(val));

  updatePlayer(id, p);
};

window.setTags = (id, val) => {
  updatePlayer(id, {
    tags: val.split(",").map(t => t.trim()).filter(Boolean)
  });
};

render();
