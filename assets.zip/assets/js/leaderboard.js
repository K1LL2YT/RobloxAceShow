import { getPlayers } from "./store.js";
import { getSeasons } from "./seasons.js";
import { renderEloGraph } from "./utils.js";

const board = document.getElementById("board");
const seasonSelect = document.getElementById("season-select");

getSeasons().forEach(s => {
  const o = document.createElement("option");
  o.value = s;
  o.textContent = s;
  seasonSelect.appendChild(o);
});

function avatar(p) {
  return p.avatar
    ? `<img src="${p.avatar}">`
    : `<div class="avatar-fallback">${p.name[0]}</div>`;
}

function render(season) {
  board.innerHTML = "";

  const players = getPlayers()
    .filter(p => p.seasons?.[season]?.participated)
    .sort((a,b)=>b.seasons[season].elo - a.seasons[season].elo);

  players.forEach((p,i)=>{
    board.innerHTML += `
      <div class="player-card"
           onclick="location.href='player.html?id=${p.id}'">
        ${avatar(p)}
        <div>
          <h3>#${i+1} ${p.name}</h3>

          <div class="archetype ${p.archetype.toLowerCase()}">
            ${p.archetype}
          </div>

          ${renderEloGraph(p.seasons[season].history)}

          <p>Elo: ${p.seasons[season].elo}</p>

          ${p.tags.map(t =>
            `<span class="role" data-tip="${t}">${t}</span>`
          ).join("")}
        </div>
      </div>
    `;
  });
}

const seasons = getSeasons();
seasonSelect.value = seasons[seasons.length - 1];
render(seasonSelect.value);
seasonSelect.onchange = () => render(seasonSelect.value);
