const SEASON_KEY = "TRAS_SEASONS";

export function getSeasons() {
  return JSON.parse(localStorage.getItem(SEASON_KEY)) || ["Season 1 – 2025"];
}

export function addSeason(name) {
  const seasons = getSeasons();
  if (!seasons.includes(name)) {
    seasons.push(name);
    localStorage.setItem(SEASON_KEY, JSON.stringify(seasons));
  }
}
